void GAUSS(double A[][N+1],double B[],double X[]) { int I,L[N+1],K,J,LK; double
S[N+1]; double SMAX,RMAX,R,XMULT,SUM;
      for (I=1;I<=N;I=I+1)
                  {L[I]=I;
                  SMAX=0.0;
                  for (J=1;J<=N;J=J+1)
                        {if (fabs(A[I][J]>SMAX))
                        SMAX=fabs(A[I][J]);
                        }
                  S[I]=SMAX;
                  }
      for (K=1;K<=N-1;K=K+1)
        {RMAX=0.0;
        for (I=K;I<=N;I=I+1)
            {R = fabs(A[L[I]][K])/S[L[I]];
            if (R<=RMAX)
            {}
            else
            {J=I;
            RMAX=R;
            }}
            LK=L[J];
            L[J]=L[K];
            L[K]=LK;
            for (I=K+1;I<=N;I=I+1)
                  {XMULT = A[L[I]][K]/A[LK][K];
                        for (J=K+1;J<=N;J=J+1)
                              A[L[I]][J] = A[L[I]][J] - XMULT*A[LK][J];
                        A[L[I]][K] = XMULT;
                  }
            }

      for (K=1;K<=N-1;K=K+1)
        {
        for (I=K+1;I<=N;I=I+1)
          {B[L[I]] = B[L[I]] - A[L[I]][K]*B[L[K]];
        //cout<<B[L[I]]<<" "<<L[I]<<endl;
        }
        }
      X[N] = B[L[N]]/A[L[N]][N];
      for (I=N-1;I>=1;I=I-1)
        {SUM = B[L[I]];
              for (J=I+1;J<=N;J=J+1)
          SUM = SUM - A[L[I]][J]*X[J];
        X[I] = SUM/A[L[I]][I];
        }
}
